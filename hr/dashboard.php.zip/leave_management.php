<?php
require_once '../config/config.php';
require_once '../auth/auth_middleware.php';

require_hr();
$db = getDBConnection();

$page_title = 'Leave Management';
include '../includes/header.php';

// Handle leave actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $leave_id = (int)$_GET['id'];
    
    switch ($action) {
        case 'approve':
            $stmt = $db->prepare("UPDATE leave_requests SET status = 'approved', approved_by = ? WHERE id = ?");
            $stmt->execute([$_SESSION['user_id'], $leave_id]);
            break;
        case 'reject':
            $stmt = $db->prepare("UPDATE leave_requests SET status = 'rejected', approved_by = ? WHERE id = ?");
            $stmt->execute([$_SESSION['user_id'], $leave_id]);
            break;
    }
}

// Get leave requests
$stmt = $db->query("
    SELECT lr.*, e.first_name, e.last_name, e.employee_id,
           d.name as department_name, lt.name as leave_type
    FROM leave_requests lr
    JOIN employees e ON lr.employee_id = e.id
    JOIN departments d ON e.department_id = d.id
    JOIN leave_types lt ON lr.leave_type_id = lt.id
    ORDER BY lr.created_at DESC
");
$leave_requests = $stmt->fetchAll();
?>

<div class="container-fluid pt-4 px-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Leave Management</h1>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Leave Requests</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Employee</th>
                                    <th>Department</th>
                                    <th>Leave Type</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Days</th>
                                    <th>Reason</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($leave_requests as $request): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($request['first_name'] . ' ' . $request['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($request['department_name']); ?></td>
                                    <td><?php echo htmlspecialchars($request['leave_type']); ?></td>
                                    <td><?php echo format_date($request['start_date']); ?></td>
                                    <td><?php echo format_date($request['end_date']); ?></td>
                                    <td><?php echo $request['total_days']; ?></td>
                                    <td><?php echo htmlspecialchars($request['reason']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $request['status'] == 'approved' ? 'success' : 
                                                 ($request['status'] == 'pending' ? 'warning' : 'danger'); 
                                        ?>">
                                            <?php echo ucfirst($request['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($request['status'] == 'pending'): ?>
                                        <div class="btn-group btn-group-sm">
                                            <a href="leave_management.php?action=approve&id=<?php echo $request['id']; ?>" class="btn btn-success">
                                                <i class="bi bi-check-lg"></i>
                                            </a>
                                            <a href="leave_management.php?action=reject&id=<?php echo $request['id']; ?>" class="btn btn-danger">
                                                <i class="bi bi-x-lg"></i>
                                            </a>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>