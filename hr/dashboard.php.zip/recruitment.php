<?php
require_once '../config/config.php';
require_once '../auth/auth_middleware.php';

require_hr();
$db = getDBConnection();

$page_title = 'Recruitment';
include '../includes/header.php';

// Display messages from hr_actions.php
if (isset($_SESSION['success_message'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>'
            . $_SESSION['success_message'] .
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['error_message'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>'
            . $_SESSION['error_message'] .
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
    unset($_SESSION['error_message']);
}

// Get job positions with error handling
try {
    $stmt = $db->query("
        SELECT jp.*, d.name as department_name, 
               COUNT(ja.id) as application_count
        FROM job_positions jp
        LEFT JOIN departments d ON jp.department_id = d.id
        LEFT JOIN job_applications ja ON jp.id = ja.job_position_id
        GROUP BY jp.id
        ORDER BY jp.created_at DESC
    ");
    $job_positions = $stmt->fetchAll();
} catch (Exception $e) {
    $job_positions = [];
    echo '<div class="alert alert-warning">Error loading job positions: ' . htmlspecialchars($e->getMessage()) . '</div>';
}
?>

<div class="container-fluid pt-4 px-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Recruitment</h1>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addJobPositionModal">
            <i class="bi bi-plus-circle me-2"></i>Add Job Position
        </button>
    </div>

    <div class="row">
        <!-- Job Positions -->
        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Job Positions</h6>
                </div>
                <div class="card-body">
                    <?php if (empty($job_positions)): ?>
                        <div class="text-center py-4">
                            <i class="bi bi-briefcase display-1 text-muted"></i>
                            <h5 class="text-muted mt-3">No Job Positions</h5>
                            <p class="text-muted">Get started by adding your first job position.</p>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addJobPositionModal">
                                <i class="bi bi-plus-circle me-2"></i>Add First Position
                            </button>
                        </div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Position Title</th>
                                    <th>Department</th>
                                    <th>Type</th>
                                    <th>Applications</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($job_positions as $position): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($position['title']); ?></td>
                                    <td><?php echo htmlspecialchars($position['department_name'] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark text-capitalize">
                                            <?php echo htmlspecialchars($position['employment_type']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info"><?php echo $position['application_count']; ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $position['status'] == 'open' ? 'success' : 'secondary'; ?>">
                                            <?php echo ucfirst($position['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="job_applications.php?position_id=<?php echo $position['id']; ?>" class="btn btn-info" title="View Applications">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="#" class="btn btn-warning" title="Edit Position">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recruitment Stats -->
        <div class="col-md-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Recruitment Statistics</h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6>Open Positions</h6>
                        <h4 class="text-primary">
                            <?php echo count(array_filter($job_positions, function($p) { 
                                return $p['status'] == 'open'; 
                            })); ?>
                        </h4>
                    </div>
                    <div class="mb-3">
                        <h6>Total Applications</h6>
                        <h4 class="text-success">
                            <?php echo array_sum(array_column($job_positions, 'application_count')); ?>
                        </h4>
                    </div>
                    <div class="mb-3">
                        <h6>Hired This Month</h6>
                        <h4 class="text-info">0</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Job Position Modal -->
<div class="modal fade" id="addJobPositionModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="hr_actions.php">
                <div class="modal-header">
                    <h5 class="modal-title">Add Job Position</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Position Title *</label>
                            <input type="text" class="form-control" name="title" required 
                                   placeholder="e.g., Senior Software Engineer">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Department *</label>
                            <select class="form-select" name="department_id" required>
                                <option value="">Select Department</option>
                                <?php
                                try {
                                    $depts = $db->query("SELECT id, name FROM departments WHERE status='active'")->fetchAll();
                                    foreach ($depts as $dept): ?>
                                    <option value="<?php echo $dept['id']; ?>">
                                        <?php echo htmlspecialchars($dept['name']); ?>
                                    </option>
                                    <?php endforeach;
                                } catch (Exception $e) {
                                    echo '<option value="">No departments available</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Employment Type *</label>
                            <select class="form-select" name="employment_type" required>
                                <option value="full-time">Full Time</option>
                                <option value="part-time">Part Time</option>
                                <option value="contract">Contract</option>
                                <option value="internship">Internship</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Salary Range</label>
                            <input type="text" class="form-control" name="salary_range" 
                                   placeholder="e.g., 1,000,000 - 2,000,000 TZS">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Job Description *</label>
                            <textarea class="form-control" name="description" rows="4" required 
                                      placeholder="Describe the role, responsibilities, and expectations..."></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Requirements *</label>
                            <textarea class="form-control" name="requirements" rows="4" required 
                                      placeholder="List the required qualifications, skills, and experience..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_job_position" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-2"></i>Add Position
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>