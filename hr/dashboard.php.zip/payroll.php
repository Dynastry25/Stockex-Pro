<?php
require_once '../config/config.php';
require_once '../auth/auth_middleware.php';

require_hr();
$db = getDBConnection();

$page_title = 'Payroll Management';
include '../includes/header.php';

// Handle payroll actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['process_payroll'])) {
    // Process payroll logic
}

// Get payroll records
$stmt = $db->query("
    SELECT p.*, e.first_name, e.last_name, e.employee_id,
           d.name as department_name
    FROM payroll p
    JOIN employees e ON p.employee_id = e.id
    JOIN departments d ON e.department_id = d.id
    ORDER BY p.pay_period DESC
");
$payroll_records = $stmt->fetchAll();
?>

<div class="container-fluid pt-4 px-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Payroll Management</h1>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#processPayrollModal">
            <i class="bi bi-calculator me-2"></i>Process Payroll
        </button>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Payroll Records</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Employee</th>
                            <th>Department</th>
                            <th>Pay Period</th>
                            <th>Basic Salary</th>
                            <th>Allowances</th>
                            <th>Deductions</th>
                            <th>Net Salary</th>
                            <th>Status</th>
                            <th>Payment Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($payroll_records as $record): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($record['first_name'] . ' ' . $record['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($record['department_name']); ?></td>
                            <td><?php echo htmlspecialchars($record['pay_period']); ?></td>
                            <td>TZS <?php echo format_currency($record['basic_salary']); ?></td>
                            <td>TZS <?php echo format_currency($record['allowances']); ?></td>
                            <td>TZS <?php echo format_currency($record['deductions']); ?></td>
                            <td><strong>TZS <?php echo format_currency($record['net_salary']); ?></strong></td>
                            <td>
                                <span class="badge bg-<?php echo $record['status'] == 'paid' ? 'success' : 'warning'; ?>">
                                    <?php echo ucfirst($record['status']); ?>
                                </span>
                            </td>
                            <td><?php echo format_date($record['payment_date']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Process Payroll Modal -->
<div class="modal fade" id="processPayrollModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="hr_actions.php">
                <div class="modal-header">
                    <h5 class="modal-title">Process Payroll</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Pay Period</label>
                            <input type="month" class="form-control" name="pay_period" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Payment Date</label>
                            <input type="date" class="form-control" name="payment_date" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Select Employees</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="selectAll">
                                <label class="form-check-label" for="selectAll">Select All Active Employees</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="process_payroll" class="btn btn-primary">Process Payroll</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>